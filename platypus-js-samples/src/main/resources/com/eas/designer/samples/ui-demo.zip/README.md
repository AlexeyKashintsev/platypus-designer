Platypus.js Ui demo
========
Sample Ui demo Platypus.js application 

## Run
In order to run the demo, execute the following commands:
```
git clone https://github.com/altsoft/UiDemo.git
cd UiDemo
gradlew runWebApp
```

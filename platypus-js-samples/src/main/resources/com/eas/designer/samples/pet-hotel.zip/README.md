pethotel
========
Sample PetHotel Platypus.js application 

## Run
In order to run the demo, execute the following commands:
```
git clone https://github.com/altsoft/pethotel.git
cd pethotel
gradlew runWebApp
```

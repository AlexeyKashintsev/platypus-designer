Platypus.js Web Socket demo
========
Sample web socket Platypus.js application 

## Run
In order to run the demo, execute the following commands:
```
git clone https://github.com/altsoft/WebSocketDemo.git
cd WebSocketDemo
gradlew runWebApp
```

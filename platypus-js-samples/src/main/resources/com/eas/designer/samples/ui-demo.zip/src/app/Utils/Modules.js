define(['CommonProperties'
            , 'FontSelectionDialog'
            , './Pallete'
]
        , function (CommonProperties, FontSelectionDialog, Pallete) {
        });

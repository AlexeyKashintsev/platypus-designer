define(function () {
    return {
        /**
         * Read reads.
         * @returns {undefined}
         */
        read: function () {},
        /**
         * Write writes.
         * @returns {undefined}
         */
        write: function () {},
        /**
         * Returns Path object.
         * @returns {Path}
         */
        path: function () {
            return {
                /**
                 * Returns whether path is absolute.
                 * @returns {Boolean}
                 */
                isAbsolute: function () {},
                /**
                 * Returns root of the filesystem.
                 * @returns {Path}
                 */
                getRoot: function () {
                },
                /**
                 * Returns nearest parent path item.
                 * @returns {Path}
                 */
                getParent: function () {
                },
                /**
                 * Resolves.
                 * @returns {Path}
                 */
                resolve: function () {
                },
                /**
                 * Relativizes.
                 * @returns {Path}
                 */
                relativize: function () {
                }
            };
        }
    };
});
Platypus.js Gradle skeleton
========
Sample Platypus.js application with Gradle as builder

## Run
In order to run the application, execute the following commands:
```
git clone https://github.com/marat-gainullin/platypus-gradle-skeleton.git
cd platypus-gradle-skeleton
gradlew runWebApp
```
After that, go to http://localhost:8085/platypus-gradle-skeleton with your browser.

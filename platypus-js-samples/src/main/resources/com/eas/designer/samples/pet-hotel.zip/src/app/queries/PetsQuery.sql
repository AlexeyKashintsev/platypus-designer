/**
 *
 * @author user
 * @name PetsQuery
 * @public
 */ 
Select * 
From PETS t1
 Where :owner_id = t1.owner_id
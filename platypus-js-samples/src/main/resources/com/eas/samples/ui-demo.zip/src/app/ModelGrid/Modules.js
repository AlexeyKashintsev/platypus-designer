define([
    'SimpleGrid'
            , 'TreeGrid'
            , 'MultiSort'
            , 'MultiHeader'
            , 'RowsDND'
            , 'FrozenRows'
            , 'FrozenColumns'
            , 'RowsSelection'
            , 'EditingInline'
            , 'EditingPopup'
            , 'Details'
            , 'Filters'
            , 'TreeView'
            , 'ListView'
            , 'OrmBinding'
            , 'Es6Binding'
            , 'ToExcel'
        ]
        , function (SimpleGrid, TreeGrid, MultiSort, MultiHeader
                , RowsDND, FrozenRows, FrozenColumns, RowsSelection
                , EditingInline, EditingPopup, Details, Filters
                , TreeView, ListView, OrmBinding, Es6Binding
                , ToExcel, ModuleName) {


        });

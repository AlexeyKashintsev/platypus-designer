define([
      './report-template'
], function(
      ReportTemplate
    ){
    return {
          ReportTemplate: ReportTemplate
    };
});

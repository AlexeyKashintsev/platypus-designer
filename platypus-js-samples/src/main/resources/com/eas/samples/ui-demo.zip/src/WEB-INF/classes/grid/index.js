define([
      './cell-data'
], function(
      CellData
    ){
    return {
          CellData: CellData
    };
});

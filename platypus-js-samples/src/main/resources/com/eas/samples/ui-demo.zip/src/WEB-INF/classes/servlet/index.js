define([
      './web-socket-client-session'
], function(
      WebSocketClientSession
    ){
    return {
          WebSocketClientSession: WebSocketClientSession
    };
});

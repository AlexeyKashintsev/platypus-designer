define([
      './anchors'
    , './button'
    , './check-box'
    , './desktop-pane'
    , './drop-down-button'
    , './formatted-field'
    , './html-area'
    , './label'
    , './check-grid-column'
    , './model-grid-column'
    , './radio-grid-column'
    , './service-grid-column'
    , './model-grid'
    , './model-check-box'
    , './model-combo'
    , './model-date'
    , './model-formatted-field'
    , './model-spin'
    , './model-text-area'
    , './password-field'
    , './progress-bar'
    , './radio-button'
    , './slider'
    , './text-area'
    , './text-field'
    , './toggle-button'
    , './anchors-pane'
    , './border-pane'
    , './box-pane'
    , './button-group'
    , './card-pane'
    , './flow-pane'
    , './grid-pane'
    , './scroll-pane'
    , './split-pane'
    , './tabbed-pane'
    , './tool-bar'
    , './action-event'
    , './cell-render-event'
    , './component-event'
    , './container-event'
    , './focus-event'
    , './item-event'
    , './key-event'
    , './mouse-event'
    , './value-change-event'
    , './window-event'
    , './form'
    , './check-menu-item'
    , './menu'
    , './menu-bar'
    , './menu-item'
    , './menu-separator'
    , './popup-menu'
    , './radio-menu-item'
], function(
      Anchors
    , Button
    , CheckBox
    , DesktopPane
    , DropDownButton
    , FormattedField
    , HtmlArea
    , Label
    , CheckGridColumn
    , ModelGridColumn
    , RadioGridColumn
    , ServiceGridColumn
    , ModelGrid
    , ModelCheckBox
    , ModelCombo
    , ModelDate
    , ModelFormattedField
    , ModelSpin
    , ModelTextArea
    , PasswordField
    , ProgressBar
    , RadioButton
    , Slider
    , TextArea
    , TextField
    , ToggleButton
    , AnchorsPane
    , BorderPane
    , BoxPane
    , ButtonGroup
    , CardPane
    , FlowPane
    , GridPane
    , ScrollPane
    , SplitPane
    , TabbedPane
    , ToolBar
    , ActionEvent
    , CellRenderEvent
    , ComponentEvent
    , ContainerEvent
    , FocusEvent
    , ItemEvent
    , KeyEvent
    , MouseEvent
    , ValueChangeEvent
    , WindowEvent
    , Form
    , CheckMenuItem
    , Menu
    , MenuBar
    , MenuItem
    , MenuSeparator
    , PopupMenu
    , RadioMenuItem
    ){
    return {
          Anchors: Anchors
        , Button: Button
        , CheckBox: CheckBox
        , DesktopPane: DesktopPane
        , DropDownButton: DropDownButton
        , FormattedField: FormattedField
        , HtmlArea: HtmlArea
        , Label: Label
        , CheckGridColumn: CheckGridColumn
        , ModelGridColumn: ModelGridColumn
        , RadioGridColumn: RadioGridColumn
        , ServiceGridColumn: ServiceGridColumn
        , ModelGrid: ModelGrid
        , ModelCheckBox: ModelCheckBox
        , ModelCombo: ModelCombo
        , ModelDate: ModelDate
        , ModelFormattedField: ModelFormattedField
        , ModelSpin: ModelSpin
        , ModelTextArea: ModelTextArea
        , PasswordField: PasswordField
        , ProgressBar: ProgressBar
        , RadioButton: RadioButton
        , Slider: Slider
        , TextArea: TextArea
        , TextField: TextField
        , ToggleButton: ToggleButton
        , AnchorsPane: AnchorsPane
        , BorderPane: BorderPane
        , BoxPane: BoxPane
        , ButtonGroup: ButtonGroup
        , CardPane: CardPane
        , FlowPane: FlowPane
        , GridPane: GridPane
        , ScrollPane: ScrollPane
        , SplitPane: SplitPane
        , TabbedPane: TabbedPane
        , ToolBar: ToolBar
        , ActionEvent: ActionEvent
        , CellRenderEvent: CellRenderEvent
        , ComponentEvent: ComponentEvent
        , ContainerEvent: ContainerEvent
        , FocusEvent: FocusEvent
        , ItemEvent: ItemEvent
        , KeyEvent: KeyEvent
        , MouseEvent: MouseEvent
        , ValueChangeEvent: ValueChangeEvent
        , WindowEvent: WindowEvent
        , Form: Form
        , CheckMenuItem: CheckMenuItem
        , Menu: Menu
        , MenuBar: MenuBar
        , MenuItem: MenuItem
        , MenuSeparator: MenuSeparator
        , PopupMenu: PopupMenu
        , RadioMenuItem: RadioMenuItem
    };
});

define([
      './session'
], function(
      Session
    ){
    return {
          Session: Session
    };
});

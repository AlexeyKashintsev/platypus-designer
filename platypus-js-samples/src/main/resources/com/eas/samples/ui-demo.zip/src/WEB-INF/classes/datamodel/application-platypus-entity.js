/* global Java */

define(['boxing'], function(B) {
    var className = "com.eas.client.model.application.ApplicationPlatypusEntity";
    var javaClass = Java.type(className);
    /**
     * Generated constructor.
     * @constructor ApplicationPlatypusEntity ApplicationPlatypusEntity
     */
    function ApplicationPlatypusEntity() {
        var maxArgs = 0;
        var delegate = arguments.length > maxArgs ?
              arguments[maxArgs] 
            : new javaClass();

        Object.defineProperty(this, "unwrap", {
            configurable: true,
            value: function() {
                return delegate;
            }
        });
        if(ApplicationPlatypusEntity.superclass)
            ApplicationPlatypusEntity.superclass.constructor.apply(this, arguments);
        delegate.setPublished(this);
        /**
         * The handler function for the event occured after the entity's data have been requeried.
         */
        this.onRequeried = new Object();
        Object.defineProperty(this, "onRequeried", {
            get: function() {
                var value = delegate.onRequeried;
                return B.boxAsJs(value);
            },
            set: function(aValue) {
                delegate.onRequeried = B.boxAsJava(aValue);
            }
        });

        /**
         * The constructor funciton for the entity's data array elements.
         */
        this.elementClass = new Object();
        Object.defineProperty(this, "elementClass", {
            get: function() {
                var value = delegate.elementClass;
                return value;
            },
            set: function(aValue) {
                delegate.elementClass = aValue;
            }
        });

    }
    /**
     * Applies the updates into the database and commits the transaction.
     * @param params Params object literal.
     * @param onSuccess Success callback. It has an argument, - updates rows count.
     * @param onFailure Failure callback. It has an argument, - exception occured while applying updates into the database.
     * @method update
     * @memberOf ApplicationPlatypusEntity
     */
    ApplicationPlatypusEntity.prototype.update = function(params, onSuccess, onFailure) {
        var delegate = this.unwrap();
        var value = delegate.update(B.boxAsJava(params), B.boxAsJava(onSuccess), B.boxAsJava(onFailure));
        return B.boxAsJs(value);
    };

    /**
     * Adds the updates into the change log as a command.
     * @param params Params object literal. Optional. If absent, entity's parameters' values will be taken.
     * @method enqueueUpdate
     * @memberOf ApplicationPlatypusEntity
     */
    ApplicationPlatypusEntity.prototype.enqueueUpdate = function(params) {
        var delegate = this.unwrap();
        var value = delegate.enqueueUpdate(B.boxAsJava(params));
        return B.boxAsJs(value);
    };

    /**
     * Applies the updates into the database and commits the transaction.
     * @param onSuccess Success callback. It has an argument, - updates rows count.
     * @param onFailure Failure callback. It has an argument, - exception occured while applying updates into the database.
     * @method executeUpdate
     * @memberOf ApplicationPlatypusEntity
     */
    ApplicationPlatypusEntity.prototype.executeUpdate = function(onSuccess, onFailure) {
        var delegate = this.unwrap();
        var value = delegate.executeUpdate(B.boxAsJava(onSuccess), B.boxAsJava(onFailure));
        return B.boxAsJs(value);
    };

    /**
     * Append data to the entity's data.
     * Appended data will be managed by model, but appending itself will not be included in data changelog.
     * @param data The plain js objects array to be appended.
     * @method append
     * @memberOf ApplicationPlatypusEntity
     */
    ApplicationPlatypusEntity.prototype.append = function(data) {
        var delegate = this.unwrap();
        var value = delegate.append(B.boxAsJava(data));
        return B.boxAsJs(value);
    };

    /**
     * Requeries the entity, only if any of its parameters has changed.
     * @param onSuccess The handler function for refresh data on success event (optional).
     * @param onFailure The handler function for refresh data on failure event (optional).
     * @method execute
     * @memberOf ApplicationPlatypusEntity
     */
    ApplicationPlatypusEntity.prototype.execute = function(onSuccess, onFailure) {
        var delegate = this.unwrap();
        var value = delegate.execute(B.boxAsJava(onSuccess), B.boxAsJava(onFailure));
        return B.boxAsJs(value);
    };

    /**
     * Queries the entity's data. Data will be fresh copy. A call to query() will be independent from other calls.
     * Subsequent calls will not cancel requests made within previous calls.
     * @param params The params object with parameters' values of query. These values will not be written to entity's parameters.
     * @param onSuccess The callback function for fresh data on success event (optional).
     * @param onFailure The callback function for fresh data on failure event (optional).
     * @method query
     * @memberOf ApplicationPlatypusEntity
     */
    ApplicationPlatypusEntity.prototype.query = function(params, onSuccess, onFailure) {
        var delegate = this.unwrap();
        var value = delegate.query(B.boxAsJava(params), B.boxAsJava(onSuccess), B.boxAsJava(onFailure));
        return B.boxAsJs(value);
    };

    /**
     * Requeries the entity's data. Forses the entity to refresh its data, no matter if its parameters has changed or not.
     * @param onSuccess The callback function for refreshed data on success event (optional).
     * @param onFailure The callback function for refreshed data on failure event (optional).
     * @method requery
     * @memberOf ApplicationPlatypusEntity
     */
    ApplicationPlatypusEntity.prototype.requery = function(onSuccess, onFailure) {
        var delegate = this.unwrap();
        var value = delegate.requery(B.boxAsJava(onSuccess), B.boxAsJava(onFailure));
        return B.boxAsJs(value);
    };


    var ScriptsClass = Java.type("com.eas.script.Scripts");
    var space = ScriptsClass.getSpace();
    space.putPublisher(className, function(aDelegate) {
        return new ApplicationPlatypusEntity(aDelegate);
    });
    return ApplicationPlatypusEntity;
});
/**
 *
 * @author user
 * @name owners
 * @public
 */ 
Select t1.owners_id, t1.lastname AS name 
From OWNERS t1
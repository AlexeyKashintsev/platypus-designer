/**
 *
 * @author user
 * @name qAllPets
 * @public
 */ 
Select * 
From PETS t1